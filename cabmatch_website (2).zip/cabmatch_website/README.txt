CABMATCH WEBSITE - VS CODE SETUP

1. Download and extract cabmatch_website.zip.
2. Open Visual Studio Code.
3. Select File > Open Folder and choose the extracted "cabmatch_website" folder.
4. Open index.html.
5. To run it:
   - Recommended: install the "Live Server" extension in VS Code.
   - Right-click index.html and choose "Open with Live Server".
   - Or double-click index.html to open it in your browser.

FEATURES IN THIS STUDENT DEMO
- CabMatch dashboard with ride and fleet summary.
- Ride booking form (pickup, drop-off, vehicle type, passengers).
- Simple nearest-available-driver matching logic.
- Driver availability list and fleet balancing message.
- Ride history updates when a ride is assigned.

IMPORTANT
This is a front-end demonstration. It uses sample driver data stored in script.js.
It does not yet have a real database, login, GPS/map tracking, payment gateway,
or live driver/customer accounts. Those features require a backend and integrations.

HOW TO CUSTOMIZE
- Edit driver names, vehicle types, areas and distances in script.js.
- Change colors and layout in style.css.
- Change page text and sections in index.html.
